from django.urls import path, re_path
from . import views

urlpatterns = [
    path('', views.index_handler, name='user_index'),
    path('course',views.course_handler, name='user_course'), # 为用户展示出已经购买的课程
    path('shoppingCart',views.shoppingCart_handler, name='user_shoppingCart'), # 为用户展示已经加入购物车的课程
    path('login',views.login_handler, name='user_login'),
    path('register',views.register_handler,name='user_register'),
    path('logout',views.logout_handler,name='user_logout'),
    re_path('purchase/(.+)',views.purchase_handler, name='user_purcharse'),
    re_path('addShoppingCart/(.+)',views.addShoppingCart_handler, name='user_addShoppingCart')
]