import datetime
import os

from django.db import models

# Create your models here.
# 如果没有写 id 会自动添加 id 并自增
# 课程种类表
from user.models import User

def save_file(instance, filename):
    # 第一个参数不管，第二个参数是上传的名称
    return os.path.join('static','video',filename)

def save_image(instance, filename):
    # 第一个参数不管，第二个参数是上传文件的地址
    return os.path.join('static','img',filename)

class Category(models.Model):
    class Meta():
        verbose_name = verbose_name_plural = '课程种类表'
    name = models.CharField(max_length=50,unique=True,verbose_name='课程种类')
    def __str__(self):
        return self.name


# 课程表：
class Course(models.Model):
    # 元组中第一个表示存储在数据库中的数据，第二个表示显示在界面上的数据, Pthon 总要求用大写表示
    STATUS_CHOICES = (
        (0,'收费'),(1,'免费')
    )
    class Meta():
        verbose_name = verbose_name_plural = '课程表'
    courseName = models.CharField(max_length=40,verbose_name='课程名称')
    fileName = models.FileField(upload_to= save_file, verbose_name='文件名称') # 文件上传
    imgname = models.ImageField(upload_to=save_image, verbose_name='课程图片') # 图片上传
    pCategory = models.ForeignKey(to=Category,related_name='courses_set',on_delete=models.CASCADE,verbose_name='课程类别')
    price = models.DecimalField(max_digits=7,decimal_places=2,default=0,verbose_name='售价',blank=True)
    summary = models.CharField(max_length=1000,default='',verbose_name='课程介绍',blank=True)
    status = models.PositiveSmallIntegerField(default=0,verbose_name='状态',blank=True, choices=STATUS_CHOICES) # 0：收费 1：免费，默认0
    createDatetime = models.DateTimeField(default=datetime.datetime.now(),verbose_name='创建时间',blank=True)
    userBuyer = models.ManyToManyField(to=User,related_name='userBuyer_set',verbose_name='购买用户',blank=True)
    userShoppingcart = models.ManyToManyField(to=User,related_name='userShoppingcart_set',verbose_name='加入购物车的用户',blank=True)