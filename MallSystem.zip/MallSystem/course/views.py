from django.shortcuts import render, HttpResponse, redirect
from .models import Course,Category
from .models import User
from django.http import StreamingHttpResponse # 返回视频流
import os
import re

# Create your views here.

def index_handler(request):
    context = request.context
    category_s = Category.objects.all()
    course_data_s = []
    for category in category_s:
        course_data_s.append(
            {
                'category':category.name,
                'course_s':category.courses_set.all()
            }
        )
    context['course_data_s'] = course_data_s
    return render(request,'index.html',context)


def course_handler(request, course_id):
    context = request.context
    try:
        course = Course.objects.get(id=course_id)
        session_user = request.session.get('session_user',None)
        if session_user:
            context['view_perssion'] = User.objects.filter(id=session_user.get('id'),userBuyer_set__id=course_id).exists
        context['course'] = course
        return render(request,'course.html',context)
    except:
        return HttpResponse(status=404)
    return render(request,'course.html')


def video_handler(request, course_id):
    context = request.context
    try:
        course = Course.objects.get(id=course_id)
        session_user = request.session['session_user']
        # 判断用户是否购买课程
        boolean_bued = User.objects.filter(id=session_user.get('id'),userBuyer_set__id=course_id).exists()
        if boolean_bued:
            context['course'] =course
            return render(request,'video.html',context)
        else:
            return redirect(reversed('course_course', args=(course_id)))
    except:
        return HttpResponse(status=404)


def videoStream_handler(request, course_id):
    def read_video(filepath,length, offset):
        with open(filepath,'rb') as f:
            f.seek(offset)
            while True:
                data = f.read(length)
                if data:
                    yield data
                else:break
    context = request.context
    try:
        course = Course.objects.get(id=course_id)
        session_user = request.session['session_user']
        # 判断用户是否购买课程
        boolean_bued = User.objects.filter(id=session_user.get('id'), userBuyer_set__id=course_id).exists()
        if boolean_bued:
            context['course'] = course
            request_range = request.headers.get('range')
            start_bytes = re.findall('=(\d+)-',request_range)
            start_bytes = int(start_bytes[0] if start_bytes else 0)
            size = os.path.getsize(course.fileName.__str__())
            last_bytes = min(start_bytes + 1024*1024,size-1) # 最多只能取 size 位， size-1 就不会循环播放了 索引字节从零开始
            length = last_bytes-start_bytes+1
            respose = StreamingHttpResponse(
                # 生成器
                read_video(course.fileName.__str__(), length=1024*1024, offset=start_bytes),
                # 状态码
                status=206
            )

            respose['Content-Length'] = str(length)
            respose['Content-Range' ] = 'bytes %s-%s/%s' % (start_bytes,last_bytes, size)  # 第一个 %s 是起始字节的位数，后一个 %s 是最后一个字节的位数， 第三个是总视频长度有多少字节
            return respose
        else:
            return redirect(reversed('course_course', args=(course_id)))
    except:
        return HttpResponse(status=404)