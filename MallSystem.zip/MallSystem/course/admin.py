from django.contrib import admin

# Register your models here.
from .models import Category, Course

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ['id', 'courseName', 'fileName', 'imgname', 'pCategory', 'price', 'summary', 'status', 'createDatetime']
    filter_horizontal = ['userBuyer', 'userShoppingcart']
    list_filter = ['status', 'createDatetime']
    search_fields = ['courseName', 'price']